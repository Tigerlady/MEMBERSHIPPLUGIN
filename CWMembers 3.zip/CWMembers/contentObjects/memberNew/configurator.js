function initMembersNew(data){
	initConfigurator(
		data,
		{
			url:'../plugins/CWMembers/contentObjects/MembersNew/configurator.cfm',
			pars:'',
			title: 'CWMembers Newest Members',
			init: function(){},
			destroy: function(){},
			validate: function(){
				return true;	
				}
		}
	);
	return true;
}