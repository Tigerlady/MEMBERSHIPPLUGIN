function initMemberList(data){
	initConfigurator(
		data,
		{
			url:'../plugins/CWMembers/contentObjects/MemberList/configurator.cfm',
			pars:'',
			title: 'CWMembers Member List Page',
			init: function(){},
			destroy: function(){},
			validate: function(){
				return true;	
				}
		}
	);
	return true;
}