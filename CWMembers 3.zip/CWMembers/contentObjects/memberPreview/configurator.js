function initMemberPreview(data){
	initConfigurator(
		data,
		{
			url:'../plugins/CWMembers/contentObjects/MemberPreview/configurator.cfm',
			pars:'',
			title: 'CWMembers Member Preview',
			init: function(){},
			destroy: function(){},
			validate: function(){
				return true;	
				}
		}
	);
	return true;
}