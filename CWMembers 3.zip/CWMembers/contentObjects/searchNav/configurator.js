function initSearchNav(data){
	initConfigurator(
		data,
		{
			url:'../plugins/CWMembers/contentObjects/searchNav/configurator.cfm',
			pars:'',
			title: 'CWMembers Search / Navigation',
			init: function(){},
			destroy: function(){},
			validate: function(){
				return true;	
				}
		}
	);
	return true;
}