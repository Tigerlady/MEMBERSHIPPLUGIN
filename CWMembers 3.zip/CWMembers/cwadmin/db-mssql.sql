/*
CWMembers Microsoft SQL Server Database
==========================================================
Application: Member Manager
Copyright 2016 - 2016, All Rights Reserved
Developer: Centric Web, Inc. | centricweb.com
Licensing: http://www.centricweb.com/
Support: http://www.centricweb.com/support
==========================================================
File: db-mssql.sql
File Date: 2016-05-16

Description: Creates CWMembers database with default data
Contents may be replaced with a sql dump of any CWMembers db

Notes: MS SQL queries are delimited with a semicolon
Edit and use at your own risk! All operations are permanent!

==========================================================
*/

-- ----------------------------
-- Table structure for [dbo].[cwmm_admin_users]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_admin_users]') IS NOT NULL DROP TABLE [dbo].[cwmm_admin_users]
;
CREATE TABLE [dbo].[cwmm_admin_users] (
[admin_user_id] int NOT NULL IDENTITY(1,1) ,
[admin_user_alias] nvarchar(255) NULL ,
[admin_username] nvarchar(255) NULL ,
[admin_password] nvarchar(255) NULL ,
[admin_access_level] nvarchar(255) NULL ,
[admin_login_date] datetime NULL ,
[admin_last_login] datetime NULL ,
[admin_user_email] nvarchar(255) NULL 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_admin_users]', RESEED, 2)
;

-- ----------------------------
-- Records of cwmm_admin_users
-- ----------------------------
SET IDENTITY_INSERT [dbo].[cwmm_admin_users] ON
;
INSERT INTO [dbo].[cwmm_admin_users] ([admin_user_id], [admin_user_alias], [admin_username], [admin_password], [admin_access_level], [admin_login_date], [admin_last_login], [admin_user_email]) VALUES (N'1', N'Developer', N'developer', N'admin', N'developer', N'2016-05-16 17:23:05.000', N'2016-05-16 16:43:12.000', N'developer@centricweb.com');
;

INSERT INTO [dbo].[cwmm_admin_users] ([admin_user_id], [admin_user_alias], [admin_username], [admin_password], [admin_access_level], [admin_login_date], [admin_last_login], [admin_user_email]) VALUES (N'3', N'Manager', N'manager', N'admin', N'manager', N'2016-05-18 10:50:59.000', N'2016-04-26 16:10:06.000', N'manager@centricweb.com');
;

SET IDENTITY_INSERT [dbo].[cwmm_admin_users] OFF
;



-- ----------------------------
-- Table structure for [dbo].[cwmm_categories_primary]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_categories_primary]') IS NOT NULL DROP TABLE [dbo].[cwmm_categories_primary]
;
CREATE TABLE [dbo].[cwmm_categories_primary] (
[category_id] int NOT NULL IDENTITY(1,1) ,
[category_name] nvarchar(225) NULL ,
[category_archive] int NULL DEFAULT '0',
[category_sort] float(53) NULL  DEFAULT '1.000',
[category_description] nvarchar(MAX) NULL, 
[category_nav] int NULL DEFAULT '1'
)

;
DBCC CHECKIDENT(N'[dbo].[cwmm_categories_primary]', RESEED, 59)
;



-- ----------------------------
-- Table structure for [dbo].[cwmm_categories_secondary]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_categories_secondary]') IS NOT NULL DROP TABLE [dbo].[cwmm_categories_secondary]
;
CREATE TABLE [dbo].[cwmm_categories_secondary] (
[secondary_id] int NOT NULL IDENTITY(1,1) ,
[secondary_name] nvarchar(255) NULL,
[secondary_archive] int NULL DEFAULT '0',
[secondary_sort] float(53) NULL DEFAULT '1.00',
[secondary_description] nvarchar(MAX) NULL, 
[secondary_nav] int NULL DEFAULT '1' 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_categories_secondary]', RESEED, 80)
;


-- ----------------------------
-- Table structure for [dbo].[cwmm_config_groups]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_config_groups]') IS NOT NULL DROP TABLE [dbo].[cwmm_config_groups]
;
CREATE TABLE [dbo].[cwmm_config_groups] (
[config_group_id] int NOT NULL IDENTITY(1,1) ,
[config_group_name] nvarchar(150) NULL ,
[config_group_sort] float(53) NULL DEFAULT '1.00',
[config_group_show_manager] int NULL DEFAULT '0',
[config_group_protected] int NULL DEFAULT '1',
[config_group_description] nvarchar(MAX) NULL 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_config_groups]', RESEED, 31)
;

-- ----------------------------
-- Records of cwmm_config_groups
-- ----------------------------
SET IDENTITY_INSERT [dbo].[cwmm_config_groups] ON
;
INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'3', N'Company Info.', N'1', N'1', N'1', N'Enter global settings for company information.');
;

INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'7', N'Admin Controls', N'1', N'0', N'1', N'Manage global settings for the admin interface.');
;
INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'8', N'Member Display', N'1', N'0', N'1', N'Manage global settings for front end display.');
;

INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'10', N'Debug Settings', N'1', N'0', N'1', N'Select the variable scopes to be shown as part of the debugging output. <br> Warning: Enabling all scopes may cause timeout errors, depending on your server settings.');
;

INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'12', N'Member Pages', N'1', N'0', N'1', N'Manage default pages for CW Member functions');
;

INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'14', N'Image Settings', N'1', N'0', N'1', N'Manage global options for Member images');
;
INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'15', N'Admin Home', N'1', N'0', N'1', N'Manage content on admin landing page');
;
INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'24', N'Member Admin Settings', N'1', N'0', N'1', N'Manage global settings related to Member administration.');
;
INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'25', N'Global Settings', N'1', N'0', N'1', N'Manage application global settings');
;


INSERT INTO [dbo].[cwmm_config_groups] ([config_group_id], [config_group_name], [config_group_sort], [config_group_show_manager], [config_group_protected], [config_group_description]) VALUES (N'30', N'Developer Settings', N'1', N'0', N'1', N'Manage developer-only options');
;

SET IDENTITY_INSERT [dbo].[cwmm_config_groups] OFF
;

-- ----------------------------
-- Table structure for [dbo].[cwmm_config_items]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_config_items]') IS NOT NULL DROP TABLE [dbo].[cwmm_config_items]
;
CREATE TABLE [dbo].[cwmm_config_items] (
[config_id] int NOT NULL IDENTITY(1,1) ,
[config_group_id] int NULL DEFAULT '0',
[config_variable] nvarchar(150) NULL ,
[config_name] nvarchar(150) NULL ,
[config_value] nvarchar(MAX) NULL ,
[config_type] nvarchar(150) NULL ,
[config_description] nvarchar(MAX) NULL ,
[config_possibles] nvarchar(MAX) NULL ,
[config_show_manager] int NULL  DEFAULT '0',
[config_sort] float(53) NULL DEFAULT '1.00',
[config_size] int NULL  DEFAULT '35',
[config_rows] int NULL  DEFAULT '5',
[config_protected] int NULL DEFAULT '0',
[config_required] int NULL DEFAULT '0',
[config_directory] nvarchar(255) NULL 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_config_items]', RESEED, 243)
;

-- ----------------------------
-- Records of cwmm_config_items
-- ----------------------------
SET IDENTITY_INSERT [dbo].[cwmm_config_items] ON
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'8', N'3', N'companyName', N'Company Name', N'Our Company', N'text', N'This is the name of the site', N'', N'0', N'4', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'9', N'3', N'companyAddress1', N'Address 1', N'123 Our Street', N'text', N'The first line of the company address', N'', N'0', N'5', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'10', N'3', N'companyAddress2', N'Address 2', N'', N'text', N'The second line of the company address (if necessary)', N'', N'0', N'6', N'35', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'11', N'3', N'companyCity', N'City', N'Our Town', N'text', N'The company''s city', N'', N'0', N'7', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'12', N'3', N'companyState', N'State/Prov', N'Washington', N'text', N'The state or province where the company is located', N'', N'0', N'8', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'13', N'3', N'companyZip', N'Postal Code', N'11111', N'text', N'The company''s postal or zip code', N'', N'0', N'9', N'20', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'14', N'3', N'companyCountry', N'Country', N'USA', N'text', N'The company''s country', N'', N'0', N'10', N'12', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'15', N'3', N'companyPhone', N'Phone', N'555-555-1234', N'text', N'The company phone number', N'', N'0', N'12', N'20', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'16', N'3', N'companyFax', N'Fax', N'', N'text', N'The company fax number', N'', N'0', N'13', N'20', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'17', N'3', N'companyEmail', N'Company Email', N'company@centricweb.com', N'text', N'This is the company email - all automated emails are sent from this address, and order confirmations are sent to this address', N'', N'0', N'3', N'35', N'0', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'32', N'8', N'appDisplayColumns', N'Number of Member Columns', N'3', N'text', N'The number of columns to be displayed on the member results page', N'', N'0', N'1', N'0', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'33', N'8', N'appDisplayPerPage', N'Results per Page', N'6', N'text', N'This value should be evenly divisible by the Number of Columns in order to ensure correct display for multi-column results', N'', N'0', N'2', N'0', N'0', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'36', N'10', N'debugApplication', N'Show Application Variables', N'0', N'boolean', N'Show application variables when debugging is turned on', N'NULL', N'0', N'6', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'37', N'10', N'debugSession', N'Show Session Variables', N'true', N'boolean', N'Show session variables when debugging is turned on', N'NULL', N'0', N'13', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'38', N'10', N'debugRequest', N'Show Request Variables', N'true', N'boolean', N'Show request variables when debugging is turned on', N'NULL', N'0', N'11', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'39', N'10', N'debugServer', N'Show Server Variables', N'0', N'boolean', N'Show server variables when debugging is turned on', N'NULL', N'0', N'12', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'40', N'10', N'debugUrl', N'Show URL Variables', N'true', N'boolean', N'Show URL variables when debugging is turned on', N'NULL', N'0', N'14', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'41', N'10', N'debugLocal', N'Show Local Variables', N'0', N'boolean', N'Show local variables when debugging is turned on', N'NULL', N'0', N'10', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'42', N'10', N'debugForm', N'Show Form Variables', N'0', N'boolean', N'Show form variables when debugging is turned on', N'NULL', N'0', N'9', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'43', N'10', N'debugCookies', N'Show Cookie Variables', N'true', N'boolean', N'Show cookie variables when debugging is turned on', N'NULL', N'0', N'8', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'44', N'10', N'debugCGI', N'Show CGI Variables', N'0', N'boolean', N'Show CGI variables when debugging is turned on', N'NULL', N'0', N'7', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'45', N'10', N'debugDisplayLink', N'Show Debug Link', N'true', N'boolean', N'If debugging is enabled, show a link in the site', N'', N'0', N'5', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'46', N'10', N'debugEnabled', N'Enable Debugging', N'true', N'boolean', N'Enable debugging output for displaying system information', N'NULL', N'0', N'2', N'0', N'0', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'53', N'8', N'appEnableCatsRelated', N'Relate Categories/Secondaries', N'true', N'boolean', N'Check the box if your categories and secondary categories are related - relationships are handled at the member level', N'NULL', N'0', N'18', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'54', N'8', N'appEnableImageZoom', N'Show Expanded Image Popup', N'true', N'boolean', N'Determines whether a popup image is shown on the details page', N'NULL', N'0', N'13', N'0', N'0', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'56', N'30', N'developerEmail', N'Developer Email', N'', N'text', N'Debugging and error emails will go to this address - if not defined, emails will go to the CompanyEmail', N'NULL', N'0', N'1', N'35', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'57', N'10', N'debugHandleErrors', N'Enable Error Handling', N'false', N'boolean', N'Determines whether error handling will be enabled on the site', N'NULL', N'0', N'1', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'61', N'13', N'appActionContinueBrowsing', N'Continue Browsing', N'Results', N'select', N'Used for the Continue Browsing and Return.', N'Member Details|Details
Member Listings|Results
Home Page|Home', N'0', N'7', N'0', N'0', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'85', N'7', N'adminMemberPaging', N'Enable Member Paging', N'true', N'boolean', N'Break members list into multiple pages', null, N'0', N'4', N'0', N'0', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'88', N'24', N'adminMemberLinksEnabled', N'Show Links to View & Edit Member', N'true', N'boolean', N'Show links in admin lists to view Members and categories on the site, and links on site to edit members (if logged in).', N'NULL', N'0', N'19', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'90', N'24', N'adminLabelCategories', N'Categories Label', N'Main Categories', N'text', N'The text label assigned to multiple top level categories (i.e. ''categories, galleries, departments'')', N'NULL', N'0', N'2', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'91', N'24', N'adminLabelCategory', N'Category Label', N'Main Category', N'text', N'The text label for a singular top level category (i.e. ''category, gallery, department'')', N'', N'0', N'3', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'92', N'24', N'adminLabelSecondary', N'Secondary Category Label', N'Secondary Category', N'text', N'The text label for a singular secondary category (i.e. ''category, gallery, department'')', null, N'0', N'7', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'93', N'24', N'adminLabelSecondaries', N'Secondary Categories Label', N'Secondary Categories', N'text', N'The text label assigned to multiple secondary categories (i.e. ''categories, galleries, departments'')', null, N'0', N'4', N'35', N'0', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'98', N'24', N'adminMemberKeywordsEnabled', N'Use Member Keywords', N'true', N'boolean', N'Show member keywords field on member form - used for enhanced member search', N'', N'0', N'13', N'0', N'0', N'1', N'0', N'');
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'99', N'24', N'adminLabelMemberKeywords', N'Member Keywords Label', N'Additional Search Terms', N'text', N'The text label for member keywords field', null, N'0', N'14', N'35', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'100', N'7', N'adminEditorEnabled', N'Use Text Editor (global)', N'true', N'boolean', N'Use the rich text (wysiwyg) editor where specified', null, N'0', N'6', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'101', N'24', N'adminMemberImageMaxKB', N'Maximum Image File Size', N'2000', N'number', N'The maximum filesize allowed for image uploads', null, N'0', N'17', N'5', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'102', N'24', N'adminMemberImageSelectorThumbsEnabled', N'Enable Image Selector Thumbnails', N'true', N'boolean', N'Enable thumbnail view when selecting from existing images', null, N'0', N'18', N'0', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'55', N'25', N'appVersionNumber', N'CW Membership  Version Number', N'1.0', N'text', N'The current CW Member version number is stored here for reference when installing or upgrading', N'NULL', N'0', N'12', N'0', N'0', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'113', N'15', N'adminWidgetSearchMembers', N'Admin Home: Search Members', N'true', N'boolean', N'Show member search on Admin Home page y/n', N'', N'0', N'3', N'35', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'116', N'10', N'debugDisplayExpanded', N'Show Debug Expanded', N'0', N'boolean', N'Show debug cfdump output expanded by default', N'', N'0', N'4', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'117', N'25', N'globalTimeOffset', N'Server Time Offset (+/-)(hh:mm)', N'0', N'number', N'The global time offset, in hours or fractional hours, from server time to displayed store time (if your server is at 1pm, and your site is at 3pm, the value would be +2)', N'', N'0', N'7', N'5', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'118', N'25', N'globalDateMask', N'Date Format', N'yyyy-mm-dd', N'select', N'A global format to be applied to all displayed dates sitewide', N'''mm/dd/yyyy'' (07/28/2011)|mm/dd/yyyy
''m/d/yy'' (7/28/11)|m/d/yy
''dd/mm/yyyy'' (28/7/2011)|dd/mm/yyyy
''d/m/yy'' (28/7/11)|d/m/yy
''yyyy-mm-dd'' (2016-07-28)|yyyy-mm-dd', N'0', N'5', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'119', N'7', N'adminEditorCategoryDescrip', N'Categories: Text Editor', N'true', N'boolean', N'Show rich text editor for category and secondary category descriptions (if no, simple text input shown)', N'', N'0', N'7', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'120', N'7', N'adminEditorMemberDescrip', N'Members: Text Editor', N'true', N'boolean', N'Show rich text editor for member descriptions (if no, simple textarea shown)', N'', N'0', N'9', N'35', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'122', N'7', N'adminThemeDirectory', N'Theme Directory', N'neutral', N'select', N'The directory for CWMembers admin theme stylesheet and graphics', N'', N'0', N'11', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'124', N'14', N'appImageDefault', N'Default Image Filename', N'noimgupload.jpg', N'text', N'To activate the default placeholder image, enter the filename of any image that has been uploaded via the member form.', N'', N'0', N'2', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'125', N'30', N'appTestModeEnabled', N'TEST MODE ON', N'0', N'boolean', N'For development purposes only, bypasses some global warnings and functions to allow for easier setup.', N'', N'0', N'1', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'126', N'25', N'appSiteUrlHttp', N'Site URL', N'', N'text', N'The website root directory url, starting with http:// or https://, no trailing slash (e.g. https://www.centricweb.com )', N'', N'0', N'1', N'45', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'129', N'10', N'debugPassword', N'Debugging Password', N'cwdebug', N'text', N'Add this password to the url to turn on debugging from any page (&debug=[debugpw])', N'', N'0', N'3', N'35', N'5', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'131', N'12', N'appPageResults', N'Results Page (filename)', N'memberlist.cfm', N'text', N'The page displaying member listings', null, N'0', N'1', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'132', N'12', N'appPageDetails', N'Details Page (filename)', N'member.cfm', N'text', N'The page displaying member details', null, N'0', N'2', N'35', N'5', N'1', N'1', null);
;

-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'136', N'7', N'adminEditorCSS', N'Text Editor CSS File (file path and name)', N'displayObjects/css/cw-styles.css', N'text', N'The css file used to define text styles in scripted text editors (member descriptions), relative to CW Members content directory', null, N'0', N'10', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'137', N'14', N'appImagesDir', N'Images Directory (folder name)', N'images', N'text', N'The folder for CW member images (created automatically if it does not already exist)', null, N'0', N'1', N'35', N'5', N'1', N'1', null);
;



INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'144', N'25', N'appDbType', N'Database Type', N'MSSQLServer', N'select', N'The database type for the application', N'mySQL|mySQL
MS SQL|MSSQLServer', N'0', N'4', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'145', N'14', N'adminImagesmanagerDeleteOrig', N'Original Images: manager Delete', N'true', N'boolean', N'Allow the ''manager'' user level to see the ''delete all originals'' button on the Member Images page', N'', N'0', N'3', N'35', N'5', N'1', N'0', null);
;



INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'155', N'7', N'adminErrorHandling', N'Use Admin Error Handling', N'false', N'boolean', N'db', N'', N'0', N'1', N'35', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'161', N'8', N'appDisplayMemberSort', N'Show Member Sort Links', N'true', N'boolean', N'Show links to sort member listings (results sortable)', N'', N'0', N'4', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'162', N'8', N'appDisplayMemberViews', N'Number of Recently Viewed Items', N'5', N'number', N'The number of recently viewed members - set to 0 to turn off recent members view.', N'', N'0', N'16', N'2', N'5', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'165', N'8', N'appDisplayListingAddToCart', N'Add to Cart from Member Listings', N'true', N'boolean', N'Show ''Add to Cart'' button on member listing page (y/n)', N'', N'0', N'7', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'166', N'13', N'appDisplayCartCustom', N'Show Custom Values in Cart', N'true', N'boolean', N'Show the custom values for member personalizations in the cart (y/n)', N'', N'0', N'4', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'167', N'8', N'appDisplayMemberSortType', N'Member Sort Links Type', N'select', N'select', N'The type of sorting display to show on the member listings page.', N'Select List (dropdown)|select
Standard Links|links', N'0', N'5', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'168', N'8', N'appDisplayMemberCategories', N'Lookup Member Categories', N'true', N'boolean', N'Get category and secondary for page titles, navigation and other functions based on member ID in url if category IDs are not provided (y/n)', N'', N'0', N'20', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'173', N'8', N'appDisplayPageLinksMax', N'Max. Paging Links', N'5', N'number', N'The maximum number of member paging links to show at once on the member listings page.', N'', N'0', N'6', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'174', N'8', N'appDisplayEmptyCategories', N'Show Empty Categories', N'0', N'boolean', N'Show categories with no active members in navigation menus and search options (y/n)', N'', N'0', N'19', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'175', N'29', N'customerAccountEnabled', N'Enable Customer Account', N'true', N'boolean', N'Enable customer account functions including order and member history, and access to saved information.', N'', N'0', N'1', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'176', N'12', N'appPageAccount', N'Account Page (filename)', N'account.cfm', N'text', N'The page displaying customer account', N'', N'0', N'6', N'35', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'177', N'13', N'appDisplayCartCustomEdit', N'Edit Custom Values in Cart', N'true', N'boolean', N'Allow customer to edit custom values in the cart view (y/n)', N'', N'0', N'5', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'179', N'12', N'appPageSearch', N'Search Page (filename)', N'index.cfm', N'text', N'The page used for member search system. Leave blank if none exists. Optional  (unlike other page variables).', N'', N'0', N'7', N'35', N'5', N'1', N'0', N'');
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'180', N'27', N'mailDefaultPasswordSentIntro', N'Password Reminder Intro', N'Account Information Request', N'textarea', N'Intro text for password reminder email to customers', N'', N'0', N'15', N'45', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'181', N'27', N'mailDefaultPasswordSendEnd', N'Password Reminder Footer', N'For further assistance with your account, please contact our customer service department.', N'textarea', N'Footer text for password reminder email to customers', N'', N'0', N'16', N'45', N'5', N'1', N'1', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'182', N'3', N'companyURL', N'Company Url', N'http://www.centricweb.com', N'text', N'The web address as shown in email messages, does not have to be the same as the site home page or other global URL settings.', N'', N'0', N'2', N'35', N'5', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'195', N'8', N'appSearchMatchType', N'Keyword Search Matching Rule', N'any', N'select', N'Determines default search match to use - can be overridden wherever the search box is displayed, by passing in arguments.match_type.', N'Any Word|any
Exact Phrase|phrase
All Words|all', N'0', N'17', N'35', N'5', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'196', N'25', N'appCookieTerm', N'Cookie Expiration Term', N'240', N'text', N'Length of time to expire cookies. Options are 0 (no cookies), blank (never expire), or number of hours.', N'', N'0', N'8', N'7', N'5', N'1', N'0', null);
;
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'198', N'25', N'appCWContentDir', N'CW Content Directory: CAUTION!', N'/plugins/CWMembers/displayObjects/', N'text', N'File path from server web root to CWMembers''s content directory. This is for a file path only, not used for URLs. Value is usually ''/plugins/CWMembers/displayObjects/'' NOTE: should include trailing slash', N'', N'0', N'2.1', N'35', N'5', N'1', N'1', null);
;
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'199', N'25', N'appCWAdminDir', N'CW Admin Directory: CAUTION!', N'/plugins/CWMembers/cwadmin/', N'text', N'Path from site root to CWMembers''s admin directory, used for admin URLs. Value is usually ''/plugins/CWMembers/cwadmin/'' NOTE: should include trailing slash', N'', N'0', N'2.4', N'35', N'5', N'1', N'1', N'');
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'200', N'7', N'adminRecordsPerPage', N'Records per Page', N'20', N'select', N'Number of members, orders and customers to show per page (if paging for that item is enabled)', N'10|10
20|20
30|30
40|40
50|50
100|100', N'0', N'5', N'0', N'0', N'1', N'0', N'');
;
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'201', N'25', N'appCWMembershipSiteRoot', N'CW Store Root: CAUTION!', N'/business-directory/', N'text', N'Path from site root to page containing CW master content, added to prefix of nav urls and form actions. Value is usually ''/business-directory/'' ', N'', N'0', N'2.2', N'35', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'208', N'25', N'appInstallationDate', N'Installation Date', N'', N'text', N'Blank by default, this is set on the first page request from a newly-installed application. Useful for tracking core application updates. Simply delete the value and save to reset the timestamp on next login.', N'', N'1', N'13', N'35', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'210', N'30', N'appDataDeleteEnabled', N'Delete Test Data Enabled', N'true', N'boolean', N'If enabled, the developer will see a menu option to Delete Test Data, and the cleanup script will be enabled.', N'', N'1', N'2', N'35', N'5', N'1', N'0', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'212', N'8', N'memberPerPageOptions', N'Members Per Page List Options', N'6,12,24,48', N'text', N'A list of numeric values to be used for the per page selector - only used if sort type is select list/dropdown', N'', N'1', N'3', N'35', N'5', N'1', N'0', N'');
;


INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'245', N'8', N'appThumbsPerRow', N'Thumbnails Per Row', N'5', N'number', N'Number of thumbnail images shown in each row on the member details page', N'', N'0', N'13.5', N'2', N'0', N'1', N'0', null);
;
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'246', N'8', N'appThumbsPosition', N'Thumbnails Position', N'below', N'select', N'Position of thumbnails area on member details page', N'Top of Page|first\r\nAbove Main Image|above\r\nBelow Main Image|below', N'0', N'13.6', N'0', N'0', N'1', N'0', null);
;
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'247', N'25', N'appCWAssetsDir', N'CW Assets Directory: CAUTION!', N'/plugins/CWMembers/displayObjects/', N'text', N'Path from site root to the CWMembers content directory, added to prefix of css and javascript src attributes. Value is usually ''/plugins/CWMembers/displayObjects/'' NOTE: should include trailing slash', N'', N'0', N'2.300', N'35', N'5', N'1', N'1', null);
;

INSERT INTO [dbo].[cwmm_config_items] ([config_id], [config_group_id], [config_variable], [config_name], [config_value], [config_type], [config_description], [config_possibles], [config_show_manager], [config_sort], [config_size], [config_rows], [config_protected], [config_required], [config_directory]) VALUES (N'251', N'8', N'memberShowAll', N'Enable Show All Members', N'false', N'boolean', N'If checked, per page options will include a link to show all members', N'', N'1', N'3.500', N'35', N'5', N'1', N'0', null);
;

SET IDENTITY_INSERT [dbo].[cwmm_config_items] OFF
;



-- ----------------------------
-- Table structure for [dbo].[cwmm_image_types]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_image_types]') IS NOT NULL DROP TABLE [dbo].[cwmm_image_types]
;
CREATE TABLE [dbo].[cwmm_image_types] (
[imagetype_id] int NOT NULL IDENTITY(1,1) ,
[imagetype_name] nvarchar(255) NULL ,
[imagetype_sortorder] float(53) NULL DEFAULT '1.000',
[imagetype_folder] nvarchar(150) NULL ,
[imagetype_max_width] int NULL DEFAULT '0',
[imagetype_max_height] int NULL DEFAULT '0',
[imagetype_crop_width] int NULL DEFAULT '0',
[imagetype_crop_height] int NULL DEFAULT '0',
[imagetype_upload_group] int NULL DEFAULT '1',
[imagetype_user_edit] int NULL DEFAULT '1'
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_image_types]', RESEED, 5)
;

-- ----------------------------
-- Records of cwmm_image_types
-- ----------------------------
SET IDENTITY_INSERT [dbo].[cwmm_image_types] ON
;
INSERT INTO [dbo].[cwmm_image_types] ([imagetype_id], [imagetype_name], [imagetype_sortorder], [imagetype_folder], [imagetype_max_width], [imagetype_max_height], [imagetype_crop_width], [imagetype_crop_height], [imagetype_upload_group], [imagetype_user_edit]) VALUES (N'1', N'Listings Thumbnail', N'1', N'member_thumb', N'160', N'160', N'0', N'0', N'1', N'1');
;
INSERT INTO [dbo].[cwmm_image_types] ([imagetype_id], [imagetype_name], [imagetype_sortorder], [imagetype_folder], [imagetype_max_width], [imagetype_max_height], [imagetype_crop_width], [imagetype_crop_height], [imagetype_upload_group], [imagetype_user_edit]) VALUES (N'2', N'Details Main Image', N'2', N'member_full', N'420', N'420', N'0', N'0', N'1', N'1');
;
INSERT INTO [dbo].[cwmm_image_types] ([imagetype_id], [imagetype_name], [imagetype_sortorder], [imagetype_folder], [imagetype_max_width], [imagetype_max_height], [imagetype_crop_width], [imagetype_crop_height], [imagetype_upload_group], [imagetype_user_edit]) VALUES (N'3', N'Details Zoom Image', N'3', N'member_expanded', N'680', N'680', N'0', N'0', N'1', N'1');
;
INSERT INTO [dbo].[cwmm_image_types] ([imagetype_id], [imagetype_name], [imagetype_sortorder], [imagetype_folder], [imagetype_max_width], [imagetype_max_height], [imagetype_crop_width], [imagetype_crop_height], [imagetype_upload_group], [imagetype_user_edit]) VALUES (N'4', N'Cart Thumbnail', N'4', N'member_small', N'60', N'60', N'0', N'0', N'1', N'1');
;
INSERT INTO [dbo].[cwmm_image_types] ([imagetype_id], [imagetype_name], [imagetype_sortorder], [imagetype_folder], [imagetype_max_width], [imagetype_max_height], [imagetype_crop_width], [imagetype_crop_height], [imagetype_upload_group], [imagetype_user_edit]) VALUES (N'5', N'SquareThumb', N'5', N'member_thumb_square', N'160', N'160', N'50', N'50', N'1', N'0');
;
INSERT INTO [dbo].[cwmm_image_types] ([imagetype_id], [imagetype_name], [imagetype_sortorder], [imagetype_folder], [imagetype_max_width], [imagetype_max_height], [imagetype_crop_width], [imagetype_crop_height], [imagetype_upload_group], [imagetype_user_edit]) VALUES (N'6', N'Details Thumbnails', N'6', N'member_thumb_details', N'80', N'80', N'0', N'0', N'1', N'1');
;
SET IDENTITY_INSERT [dbo].[cwmm_image_types] OFF
;


-- ----------------------------
-- Table structure for [dbo].[cwmm_member_categories_primary]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_member_categories_primary]') IS NOT NULL DROP TABLE [dbo].[cwmm_member_categories_primary]
;
CREATE TABLE [dbo].[cwmm_member_categories_primary] (
[member2category_id] int NOT NULL IDENTITY(1,1) ,
[member2category_member_id] int NULL DEFAULT '0',
[member2category_category_id] int NULL DEFAULT '0' 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_member_categories_primary]', RESEED, 535)
;

-- ----------------------------
-- Table structure for [dbo].[cwmm_member_categories_secondary]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_member_categories_secondary]') IS NOT NULL DROP TABLE [dbo].[cwmm_member_categories_secondary]
;
CREATE TABLE [dbo].[cwmm_member_categories_secondary] (
[member2secondary_id] int NOT NULL IDENTITY(1,1) ,
[member2secondary_member_id] int NULL DEFAULT '0',
[member2secondary_secondary_id] int NULL DEFAULT '0' 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_member_categories_secondary]', RESEED, 991)
;

-- ----------------------------
-- Table structure for [dbo].[cwmm_member_images]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_member_images]') IS NOT NULL DROP TABLE [dbo].[cwmm_member_images]
;
CREATE TABLE [dbo].[cwmm_member_images] (
[member_image_id] int NOT NULL IDENTITY(1,1) ,
[member_image_member_id] int NULL DEFAULT '0',
[member_image_imagetype_id] int NULL DEFAULT '0',
[member_image_filename] nvarchar(255) NULL ,
[member_image_sortorder] float(53) NULL DEFAULT '1.000',
[member_image_caption] nvarchar(255) NULL 
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_member_images]', RESEED, 503)
;

-- ----------------------------
-- Table structure for [dbo].[cwmm_members]
-- ----------------------------
IF OBJECT_ID('[dbo].[cwmm_members]') IS NOT NULL DROP TABLE [dbo].[cwmm_members]
;
CREATE TABLE [dbo].[cwmm_members] (
[member_id] int NOT NULL IDENTITY(1,1) ,
[member_name] nvarchar(255) NULL ,
[member_address] nvarchar(255) NULL,
[member_city] nvarchar(75) NULL,
[member_state] nvarchar(75) NULL,
[member_zip] nvarchar(15) NULL,
[member_work_phone] nvarchar(20) NULL,
[member_mobile_phone] nvarchar(20) NULL,
[member_fax] nvarchar(20) NULL,
[member_website] nvarchar(100) NULL,
[member_description] nvarchar(MAX) NULL ,
[member_preview_description] nvarchar(MAX) NULL ,
[member_sort] float(53) NULL DEFAULT '1.00',
[member_on_web] int NULL DEFAULT '1',
[member_archive] int NULL DEFAULT '0',
[member_date_modified] datetime NULL ,
[member_notes] nvarchar(MAX) NULL ,
[member_keywords] nvarchar(MAX) NULL ,
[member_email1] nvarchar(100) NULL,
[member_email2] nvarchar(100) NULL,
[member_email3] nvarchar(100) NULL,
[member_email4] nvarchar(100) NULL,
[member_Primary_Contact] nvarchar(100) NULL,
[member_Primary_Contact_position] nvarchar(150) NULL,
[member_other_contacts] nvarchar(255) NULL,
[member_date_joined] datetime NULL ,
[member_paid_years] nvarchar(255)
)


;
DBCC CHECKIDENT(N'[dbo].[cwmm_members]', RESEED, 115)
;

-- ----------------------------
-- Records of cwmm_members
-- ----------------------------
SET IDENTITY_INSERT [dbo].[cwmm_members] ON
;
INSERT INTO [dbo].[cwmm_members] ([member_id], [member_name],[member_address], [member_city], [member_state], [member_zip], [member_work_phone], [member_mobile_phone], [member_fax], [member_website], [member_description], [member_preview_description], [member_sort], [member_on_web], [member_archive],  [member_date_modified], [member_notes], [member_keywords], [member_email1], [member_email2], [member_email3], [member_email4], [member_Primary_Contact], [member_Primary_Contact_position], [member_other_contacts], [member_date_joined], [member_paid_years]) VALUES (N'1',  N'Centric Web, Inc', N'19W169 Millbrook Court', N'Downers Grove', N'Illinois', N'60516', N'630-541-9956', N'',N'',N'https://www.centricweb.com', N'<p>primary test of the information on the descriptions</p>
<p>this is  test of my new member project</p>
<p>This is the longer description</p>
<p>It shows up on the details page</p>
<p>Put what ever you want</p>', N'<p>short descriptions</p>', N'1', N'1', N'0', N'2016-05-10 11:26:25.000', N'<p>Internal notes</p>', N'web design', N'info@centricweb.com', N'barbara@centricweb.com', N'melvin@centricweb.com', N'', N'', N'Barbara ONeal', N'Melvin Renowden', N'2016-01-01 11:26:25.000', N'2015,2016');
;


-- ----------------------------
-- Indexes structure for table cwmm_admin_users
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_admin_users]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_admin_users] ADD PRIMARY KEY ([admin_user_id])
;



-- ----------------------------
-- Indexes structure for table cwmm_categories_primary
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_categories_primary]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_categories_primary] ADD PRIMARY KEY ([category_id])
;

-- ----------------------------
-- Indexes structure for table cwmm_categories_secondary
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_categories_secondary]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_categories_secondary] ADD PRIMARY KEY ([secondary_id])
;

-- ----------------------------
-- Indexes structure for table cwmm_config_groups
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_config_groups]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_config_groups] ADD PRIMARY KEY ([config_group_id])
;

-- ----------------------------
-- Indexes structure for table cwmm_config_items
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_config_items]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_config_items] ADD PRIMARY KEY ([config_id])
;

-- ----------------------------
-- Indexes structure for table cwmm_countries
-- ----------------------------



-- ----------------------------
-- Indexes structure for table cwmm_image_types
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_image_types]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_image_types] ADD PRIMARY KEY ([imagetype_id])
;


-- ----------------------------
-- Indexes structure for table cwmm_member_categories_primary
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_member_categories_primary]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_member_categories_primary] ADD PRIMARY KEY ([member2category_id])
;

-- ----------------------------
-- Indexes structure for table cwmm_member_images
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_member_images]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_member_images] ADD PRIMARY KEY ([member_image_id])
;

-- ----------------------------
-- Indexes structure for table cwmm_members
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table [dbo].[cwmm_members]
-- ----------------------------
ALTER TABLE [dbo].[cwmm_members] ADD PRIMARY KEY ([member_id])
;


