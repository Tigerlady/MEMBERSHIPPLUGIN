/*
CWMembers mySQL Database
==========================================================
Application: CWMembers
Copyright 2016 - 2016, All Rights Reserved
Developer: Centric Web, Inc. | CentricWeb.com
Licensing: https://www.centricweb.com/eula
Support: https://www.centricweb.com/support
==========================================================
File: db-mysql.sql
File Date: 2016-05-16

Description: Creates CWMembers database with default data
Contents may be replaced with a sql dump of any CWMembers db

Note: Edit and use at your own risk! All operations are permanent!
==========================================================
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `cwmm_admin_users`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_admin_users`;
CREATE TABLE `cwmm_admin_users` (
  `admin_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_user_alias` varchar(255) DEFAULT NULL,
  `admin_username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `admin_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `admin_access_level` varchar(255) DEFAULT NULL,
  `admin_login_date` datetime DEFAULT NULL,
  `admin_last_login` datetime DEFAULT NULL,
  `admin_user_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`admin_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_admin_users
-- ----------------------------
INSERT INTO `cwmm_admin_users` VALUES ('1', 'Developer', 'developer', 'admin', 'developer', '2016-05-16 17:23:05', '2016-12-16 16:43:12', 'developer@CentricWeb.com');
INSERT INTO `cwmm_admin_users` VALUES ('2', 'Manager', 'manager', 'admin', 'manager', '2016-05-18 10:50:59', '2016-04-26 16:10:06', 'manager@CentricWeb.com');




-- ----------------------------
-- Table structure for `cwmm_categories_primary`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_categories_primary`;
CREATE TABLE `cwmm_categories_primary` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(75) DEFAULT NULL,
  `category_archive` smallint(6) DEFAULT '0',
  `category_sort` float(11,3) DEFAULT '1.000',
  `category_description` text,
  `category_nav` smallint(6) DEFAULT '1',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_categories_primary
-- ----------------------------

-- ----------------------------
-- Table structure for `cwmm_categories_secondary`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_categories_secondary`;
CREATE TABLE `cwmm_categories_secondary` (
  `secondary_id` int(11) NOT NULL AUTO_INCREMENT,
  `secondary_name` varchar(100) DEFAULT NULL,
  `secondary_archive` smallint(6) DEFAULT '0',
  `secondary_sort` float(11,3) DEFAULT '1.000',
  `secondary_description` text,
  `secondary_nav` smallint(6) DEFAULT '1',
  PRIMARY KEY (`secondary_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_categories_secondary
-- ----------------------------

-- ----------------------------
-- Table structure for `cwmm_config_groups`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_config_groups`;
CREATE TABLE `cwmm_config_groups` (
  `config_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_group_name` varchar(50) DEFAULT NULL,
  `config_group_sort` float(11,3) DEFAULT '1.000',
  `config_group_show_manager` tinyint(4) DEFAULT '0',
  `config_group_protected` tinyint(4) DEFAULT '1',
  `config_group_description` text,
  PRIMARY KEY (`config_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_config_groups
-- ----------------------------
INSERT INTO `cwmm_config_groups` VALUES ('3', 'Company Info.', '1.000', '1', '1', 'Enter global settings for company information.');
INSERT INTO `cwmm_config_groups` VALUES ('7', 'Admin Controls', '1.000', '0', '1', 'Manage global settings for the admin interface.');
INSERT INTO `cwmm_config_groups` VALUES ('8', 'Member Display', '1.000', '0', '1', 'Manage global settings for front end display.');
INSERT INTO `cwmm_config_groups` VALUES ('10', 'Debug Settings', '1.000', '0', '1', 'Select the variable scopes to be shown as part of the debugging output. <br> Warning: Enabling all scopes may cause timeout errors, depending on your server settings.');
INSERT INTO `cwmm_config_groups` VALUES ('24', 'Member Admin Settings', '1.000', '0', '1', 'Manage global settings related to member administration.');
INSERT INTO `cwmm_config_groups` VALUES ('25', 'Global Settings', '1.000', '0', '1', 'Manage application global settings');
INSERT INTO `cwmm_config_groups` VALUES ('27', 'Email Settings', '1.000', '0', '1', 'Sitewide email options and message content    (<a href=\"email-sample.cfm\" target=\"_blank\">View sample email format</a>)');
INSERT INTO `cwmm_config_groups` VALUES ('14', 'Image Settings', '1.000', '0', '1', 'Manage global options for member images');
INSERT INTO `cwmm_config_groups` VALUES ('15', 'Admin Home', '1.000', '0', '1', 'Manage content on admin landing page');
INSERT INTO `cwmm_config_groups` VALUES ('30', 'Developer Settings', '1.000', '0', '1', 'Manage developer-only options');
-- ----------------------------
-- Table structure for `cwmm_config_items`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_config_items`;
CREATE TABLE `cwmm_config_items` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_group_id` int(11) DEFAULT '0',
  `config_variable` varchar(50) DEFAULT NULL,
  `config_name` varchar(50) DEFAULT NULL,
  `config_value` text,
  `config_type` varchar(50) DEFAULT NULL,
  `config_description` text,
  `config_possibles` text,
  `config_show_manager` tinyint(4) DEFAULT '0',
  `config_sort` float(11,3) DEFAULT '1.000',
  `config_size` int(3) NOT NULL DEFAULT '35',
  `config_rows` int(3) NOT NULL DEFAULT '5',
  `config_protected` tinyint(4) DEFAULT '0',
  `config_required` tinyint(1) NOT NULL DEFAULT '0',
  `config_directory` varchar(0) DEFAULT NULL,
  PRIMARY KEY (`config_id`),
  KEY `config_group_id_idx` (`config_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_config_items
-- ----------------------------
INSERT INTO `cwmm_config_items` VALUES ('8', '3', 'companyName', 'Company Name', 'Our Company', 'text', 'This is the name of the store, used on invoices and in email confirmations', '', '0', '4.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('9', '3', 'companyAddress1', 'Address 1', '123 Our Street', 'text', 'The first line of the company address', '', '0', '5.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('10', '3', 'companyAddress2', 'Address 2', '', 'text', 'The second line of the company address (if necessary)', '', '0', '6.000', '35', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('11', '3', 'companyCity', 'City', 'Our Town', 'text', 'The company\'s city', '', '0', '7.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('12', '3', 'companyState', 'State/Prov', 'Washington', 'text', 'The state or province where the company is  located', '', '0', '8.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('13', '3', 'companyZip', 'Postal Code', '11111', 'text', 'The company\'s postal or zip code', '', '0', '9.000', '20', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('14', '3', 'companyCountry', 'Country', 'USA', 'text', 'The company\'s country', '', '0', '10.000', '12', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('15', '3', 'companyPhone', 'Phone', '555-555-1234', 'text', 'The company phone number', '', '0', '12.000', '20', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('16', '3', 'companyFax', 'Fax', '', 'text', 'The company fax number', '', '0', '13.000', '20', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('17', '3', 'companyEmail', 'Company Email', 'company@CentricWeb.com', 'text', 'This is the company email - all automated emails are sent from this address, and order confirmations are sent to this address', '', '0', '3.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('32', '8', 'appDisplayColumns', 'Number of Member Columns', '3', 'text', 'The number of columns to be displayed on the member results page', '', '0', '1.000', '0', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('33', '8', 'appDisplayPerPage', 'Results per Page', '6', 'text', 'This value should be evenly divisible by the Number of Columns in order to ensure correct display for multi-column results', '', '0', '2.000', '0', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('36', '10', 'debugApplication', 'Show Application Variables', '0', 'boolean', 'Show application variables when debugging is turned on', 'NULL', '0', '6.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('37', '10', 'debugSession', 'Show Session Variables', 'true', 'boolean', 'Show session variables when debugging is turned on', 'NULL', '0', '13.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('38', '10', 'debugRequest', 'Show Request Variables', 'true', 'boolean', 'Show request variables when debugging is turned on', 'NULL', '0', '11.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('39', '10', 'debugServer', 'Show Server Variables', '0', 'boolean', 'Show server variables when debugging is turned on', 'NULL', '0', '12.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('40', '10', 'debugUrl', 'Show URL Variables', 'true', 'boolean', 'Show URL variables when debugging is turned on', 'NULL', '0', '14.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('41', '10', 'debugLocal', 'Show Local Variables', '0', 'boolean', 'Show local variables when debugging is turned on', 'NULL', '0', '10.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('42', '10', 'debugForm', 'Show Form Variables', '0', 'boolean', 'Show form variables when debugging is turned on', 'NULL', '0', '9.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('43', '10', 'debugCookies', 'Show Cookie Variables', 'true', 'boolean', 'Show cookie variables when debugging is turned on', 'NULL', '0', '8.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('44', '10', 'debugCGI', 'Show CGI Variables', '0', 'boolean', 'Show CGI variables when debugging is turned on', 'NULL', '0', '7.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('45', '10', 'debugDisplayLink', 'Show Debug Link', 'true', 'boolean', 'If debugging is enabled, show a link in the store', '', '0', '5.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('46', '10', 'debugEnabled', 'Enable Debugging', 'true', 'boolean', 'Enable debugging output for displaying system information', 'NULL', '0', '2.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('53', '8', 'appEnableCatsRelated', 'Relate Categories/Secondaries', 'true', 'boolean', 'Check the box if your categories and secondary categories are related - relationships are handled at the member level', 'NULL', '0', '18.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('54', '8', 'appEnableImageZoom', 'Show Expanded Image Popup', 'true', 'boolean', 'Determines whether a popup image is shown on the details page', 'NULL', '0', '13.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('55', '25', 'appVersionNumber', 'CWMembers Version Number', '1.0', 'text', 'The current CWMembers version number is stored here for reference when installing or upgrading', 'NULL', '0', '12.000', '0', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('56', '30', 'developerEmail', 'Developer Email', '', 'text', 'Debugging and error emails will go to this address - if not defined, emails will go to the CompanyEmail', 'NULL', '0', '1.000', '35', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('57', '10', 'debugHandleErrors', 'Enable Error Handling', 'false', 'boolean', 'Determines whether error handling will be enabled on the site', 'NULL', '0', '1.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('85', '7', 'adminMemberPaging', 'Enable Member Paging', 'true', 'boolean', 'Break members list into multiple pages', null, '0', '4.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('155', '7', 'adminErrorHandling', 'Use Admin Error Handling', 'false', 'boolean', 'db', '', '0', '1.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('129', '10', 'debugPassword', 'Debugging Password', 'cwdebug', 'text', 'Add this password to the url to turn on debugging from any page (&debug=[debugpw])', '', '0', '3.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('125', '30', 'appTestModeEnabled', 'TEST MODE ON', '0', 'boolean', 'For development purposes only, bypasses some global warnings and functions to allow for easier setup.', '', '0', '1.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('124', '14', 'appImageDefault', 'Default Image Filename', 'noimgupload.jpg', 'text', 'To activate the default placeholder image, enter the filename of any image that has been uploaded via the member form.', '', '0', '2.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('126', '25', 'appSiteUrlHttp', 'Site URL', '', 'text', 'The website root directory url, starting with http:// or https://, no trailing slash (e.g. https://www.centricweb.com )', '', '0', '1.000', '45', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('88', '24', 'adminMemberLinksEnabled', 'Show Links to View & Edit Member', 'true', 'boolean', 'Show links in admin lists to view members and categories on the site, and links on site to edit member (if logged in).', 'NULL', '0', '19.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('90', '24', 'adminLabelCategories', 'Categories Label', 'Main Categories', 'text', 'The text label assigned to multiple top level categories (i.e. \'categories, galleries, departments\')', 'NULL', '0', '2.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('91', '24', 'adminLabelCategory', 'Category Label', 'Main Category', 'text', 'The text label for a singular top level category (i.e. \'category, gallery, department\')', '', '0', '3.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('92', '24', 'adminLabelSecondary', 'Secondary Category Label', 'Secondary Category', 'text', 'The text label for a singular secondary category (i.e. \'category, gallery, department\')', null, '0', '7.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('93', '24', 'adminLabelSecondaries', 'Secondary Categories Label', 'Secondary Categories', 'text', 'The text label assigned to multiple secondary categories (i.e. \'categories, galleries, departments\')', null, '0', '4.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('98', '24', 'adminMemberKeywordsEnabled', 'Use Member Keywords', 'true', 'boolean', 'Show member keywords field on member form - used for enhanced member search', '', '0', '13.000', '0', '0', '1', '0', '');
INSERT INTO `cwmm_config_items` VALUES ('99', '24', 'adminLabelMemberKeywords', 'Member Keywords Label', 'Additional Search Terms', 'text', 'The text label for member keywords field', null, '0', '14.000', '35', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('100', '7', 'adminEditorEnabled', 'Use Text Editor (global)', 'true', 'boolean', 'Use the rich text (wysiwyg) editor where specified', null, '0', '6.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('101', '24', 'adminMemberImageMaxKB', 'Maximum Image File Size', '2000', 'number', 'The maximum filesize allowed for image uploads', null, '0', '17.000', '5', '0', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('102', '24', 'adminMemberImageSelectorThumbsEnabled', 'Enable Image Selector Thumbnails', 'true', 'boolean', 'Enable thumbnail view when selecting from existing images', null, '0', '18.000', '0', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('111', '15', 'adminWidgetMembersRecent', 'Admin Home: Recent Members', '5', 'number', 'Number of top selling members to show in the admin home page preview (0 hides this widget)', '', '0', '5.000', '3', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('113', '15', 'adminWidgetSearchMembers', 'Admin Home: Search Members', 'true', 'boolean', 'Show member search on Admin Home page y/n', '', '0', '3.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('116', '10', 'debugDisplayExpanded', 'Show Debug Expanded', '0', 'boolean', 'Show debug cfdump output expanded by default', '', '0', '4.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('117', '25', 'globalTimeOffset', 'Server Time Offset (+/-)(hh:mm)', '0', 'number', 'The global time offset, in hours or fractional hours, from server time to displayed store time (if your server is at 1pm, and your site is at 3pm, the value would be +2)', '', '0', '7.000', '5', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('118', '25', 'globalDateMask', 'Date Format', 'yyyy-mm-dd', 'select', 'A global format to be applied to all displayed dates sitewide', '\'mm/dd/yyyy\' (07/28/2011)|mm/dd/yyyy\r\n\'m/d/yy\' (7/28/11)|m/d/yy\r\n\'dd/mm/yyyy\' (28/7/2011)|dd/mm/yyyy\r\n\'d/m/yy\' (28/7/11)|d/m/yy\r\n\'yyyy-mm-dd\' (2016-07-28)|yyyy-mm-dd', '0', '5.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('131', '12', 'appPageResults', 'Results Page (filename)', 'memberlist.cfm', 'text', 'The page displaying member listings', null, '0', '1.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('132', '12', 'appPageDetails', 'Details Page (filename)', 'member.cfm', 'text', 'The page displaying member details', null, '0', '2.000', '35', '5', '1', '1', null);
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO `cwmm_config_items` VALUES ('136', '7', 'adminEditorCSS', 'Text Editor CSS File (file path and name)', 'displayObjects/css/cw-styles.css', 'text', 'The css file used to define text styles in scripted text editors (member descriptions), relative to CW content directory', null, '0', '10.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('137', '14', 'appImagesDir', 'Images Directory (folder name)', 'images', 'text', 'The folder for CW member images (created automatically if it does not already exist)', null, '0', '1.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('119', '7', 'adminEditorCategoryDescrip', 'Categories: Text Editor', 'true', 'boolean', 'Show rich text editor for category and secondary category descriptions (if no, simple text input shown)', '', '0', '7.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('120', '7', 'adminEditorMemberDescrip', 'Members: Text Editor', 'true', 'boolean', 'Show rich text editor for member descriptions (if no, simple textarea shown)', '', '0', '9.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('122', '7', 'adminThemeDirectory', 'Theme Directory', 'neutral', 'select', 'The directory for CWMembers admin theme stylesheet and graphics', '', '0', '11.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('143', '25', 'globalLocale', 'Default Locale (nationality)', 'English (US)', 'select', 'The default nationality or locale for your site, used to automatically set other location-specific settings', 'Chinese(China)|Chinese (China)\r\nChinese(Hong Kong)|Chinese (Hong Kong)\r\nChinese(Taiwan)|Chinese (Taiwan)\r\nEnglish(Australian)|English (Australian)\r\nEnglish(Canadian)|English (Canadian)\r\nEnglish(New Zealand)|English (New Zealand)\r\nEnglish(UK)|English (UK)\r\nEnglish(US)|English (US)\r\nFrench(Belgian)|French (Belgian)\r\nFrench(Canadian)|French (Canadian)\r\nFrench(Standard)|French (Standard)\r\nFrench(Swiss)|French (Swiss)\r\nGerman(Austrian)|German (Austrian)\r\nGerman(Standard)|German (Standard)\r\nGerman(Swiss)|German (Swiss)\r\nItalian(Standard)|Italian (Standard)\r\nItalian(Swiss)|Italian (Swiss)\r\nJapanese|Japanese\r\nKorean|Korean\r\nNorwegian(Bokmal)|Norwegian (Bokmal)\r\nNorwegian(Nynorsk)|Norwegian (Nynorsk)\r\nPortuguese(Brazilian)|Portuguese (Brazilian)\r\nPortuguese(Standard)|Portuguese (Standard)\r\nSpanish(Standard)|Spanish (Standard)\r\nSpanish(Modern)|Spanish (Modern)\r\nSwedish|Swedish', '0', '6.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('144', '25', 'appDbType', 'Database Type', 'mySQL', 'select', 'The database type for the application', 'mySQL|mySQL\r\nMS SQL|MSSQLServer', '0', '4.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('196', '25', 'appCookieTerm', 'Cookie Expiration Term', '240', 'text', 'Length of time to expire cookies. Options are 0 (no cookies), blank (never expire), or number of hours.', '', '0', '8.000', '7', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('145', '14', 'adminImagesManagerDeleteOrig', 'Original Images: Manager Delete', 'true', 'boolean', 'Allow the \'Manager\' user level to see the \'delete all originals\' button on the Member Images page', '', '0', '3.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('162', '8', 'appDisplayMemberViews', 'Number of Recently Viewed Items', '5', 'number', 'The number of recently viewed members - set to 0 to turn off recent members view.', '', '0', '16.000', '2', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('167', '8', 'appDisplayMemberSortType', 'Member Sort Links Type', 'select', 'select', 'The type of sorting display to show on the member listings page.', 'Select List (dropdown)|select\r\nStandard Links|links', '0', '5.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('168', '8', 'appDisplayMemberCategories', 'Lookup Member Categories', 'true', 'boolean', 'Get category and secondary for page titles, navigation and other functions based on member ID in url if category IDs are not provided (y/n)', '', '0', '20.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('173', '8', 'appDisplayPageLinksMax', 'Max. Paging Links', '5', 'number', 'The maximum number of member paging links to show at once on the member listings page.', '', '0', '6.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('174', '8', 'appDisplayEmptyCategories', 'Show Empty Categories', '0', 'boolean', 'Show categories with no active members in navigation menus and search options (y/n)', '', '0', '19.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('179', '12', 'appPageSearch', 'Search Page (filename)', 'index.cfm', 'text', 'The page used for member search system. Leave blank if none exists. Optional  (unlike other page variables).', '', '0', '7.000', '35', '5', '1', '0', '');
INSERT INTO `cwmm_config_items` VALUES ('182', '3', 'companyURL', 'Company Url', 'https://www.centricweb.com', 'text', 'The web address as shown in email messages, does not have to be the same as the site home page or other global URL settings.', '', '0', '2.000', '35', '5', '1', '1', null);
INSERT INTO `cwmm_config_items` VALUES ('195', '8', 'appSearchMatchType', 'Keyword Search Matching Rule', 'any', 'select', 'Determines default search match to use - can be overridden wherever the search box is displayed, by passing in arguments.match_type.', 'Any Word|any\r\nExact Phrase|phrase\r\nAll Words|all', '0', '17.000', '35', '5', '1', '0', null);
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO `cwmm_config_items` VALUES ('198', '25', 'appCWContentDir', 'CW Content Path: CAUTION!', '/plugins/CWMembers/displayObjects/', 'text', 'File path from server web root to CWMembers\'s content directory. This is for a file path only, not used for URLs. Value is usually  \'/plugins/CWMembers/displayObjects/\' NOTE: should include trailing slash', '', '0', '2.100', '35', '5', '1', '1', null);
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO `cwmm_config_items` VALUES ('199', '25', 'appCWMembershipSiteRoot', 'CW Store Root: CAUTION!', '/business-directory/', 'text', 'Path from site root to page containing CW master content, added to prefix of nav urls and form actions. Value is usually  \'/index.cfm/store/\' ', '', '0', '2.2', '35', '5', '1', '0', null);
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO `cwmm_config_items` VALUES ('200', '25', 'appCWAdminDir', 'CW Admin Directory: CAUTION!', '/plugins/CWMembers/cwadmin/', 'text', 'Path from site root to CWMembers\'s admin directory, used for admin URLs. Value is usually \'/plugins/CWMembers/cwadmin/\' NOTE: should include trailing slash', '', '0', '2.400', '35', '5', '1', '1', '');
INSERT INTO `cwmm_config_items` VALUES ('201', '7', 'adminRecordsPerPage', 'Records per Page', '20', 'select', 'Number of members, orders and customers to show per page (if paging for that item is enabled)', '10|10\r\n20|20\r\n30|30\r\n40|40\r\n50|50\r\n100|100', '0', '5.000', '0', '0', '1', '0', '');
INSERT INTO `cwmm_config_items` VALUES ('208', '25', 'appInstallationDate', 'Installation Date', '', 'text', 'Blank by default, this is set on the first page request from a newly-installed application. Useful for tracking core application updates. Simply delete the value and save to reset the timestamp on next login.', '', '1', '13.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('210', '30', 'appDataDeleteEnabled', 'Delete Test Data Enabled', 'true', 'boolean', 'If enabled, the developer will see a menu option to Delete Test Data, and the cleanup script will be enabled.', '', '1', '2.000', '35', '5', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('245', '8', 'appThumbsPerRow', 'Thumbnails Per Row', '5', 'number', 'Number of thumbnail images shown in each row on the member details page', '', '0', '13.5', '2', '0', '1', '0', null);
INSERT INTO `cwmm_config_items` VALUES ('246', '8', 'appThumbsPosition', 'Thumbnail Position', 'below', 'select', 'Position of thumbnails area on member details page', 'Top of Page|first\r\nAbove Main Image|above\r\nBelow Main Image|below', '0', '13.6', '0', '0', '1', '0', null);
-- CWMURA EDIT PATH FOR MURA LOCATION --
INSERT INTO `cwmm_config_items` VALUES ('247', '25', 'appCWAssetsDir', 'CW Assets Directory: CAUTION!', '/plugins/CWMembers/displayObjects/', 'text', 'Path from site root to CWMembers file contents, added to prefix of css and javascript src attributes. Value is usually \'/plugins/CWMembers/displayObjects/\' NOTE: should include trailing slash', '', '0', '2.300', '35', '5', '1', '0', '');
INSERT INTO `cwmm_config_items` VALUES ('251', '8', 'memberShowAll', 'Enable Show All Members', 'false', 'boolean', 'If checked, per page options will include a link to show all members', '', '1', '3.000', '35', '5', '1', '0', '');



-- Table structure for `cwmm_image_types`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_image_types`;
CREATE TABLE `cwmm_image_types` (
  `imagetype_id` int(11) NOT NULL AUTO_INCREMENT,
  `imagetype_name` varchar(100) DEFAULT NULL,
  `imagetype_sortorder` float(11,3) DEFAULT '1.000',
  `imagetype_folder` varchar(50) DEFAULT NULL,
  `imagetype_max_width` int(10) DEFAULT '0',
  `imagetype_max_height` int(10) DEFAULT '0',
  `imagetype_crop_width` int(10) DEFAULT '0',
  `imagetype_crop_height` int(10) DEFAULT '0',
  `imagetype_upload_group` int(2) DEFAULT '1',
  `imagetype_user_edit` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`imagetype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_image_types
-- ----------------------------
INSERT INTO `cwmm_image_types` VALUES ('1', 'Listings Thumbnail', '1.000', 'member_thumb', '160', '160', '0', '0', '1', '1');
INSERT INTO `cwmm_image_types` VALUES ('2', 'Details Main Image', '2.000', 'member_full', '420', '420', '0', '0', '1', '1');
INSERT INTO `cwmm_image_types` VALUES ('3', 'Details Zoom Image', '3.000', 'member_expanded', '680', '680', '0', '0', '1', '1');
INSERT INTO `cwmm_image_types` VALUES ('4', 'Cart Thumbnail', '4.000', 'member_small', '60', '60', '0', '0', '1', '1');
INSERT INTO `cwmm_image_types` VALUES ('5', 'SquareThumb', '5.000', 'member_thumb_square', '160', '160', '50', '50', '1', '0');
INSERT INTO `cwmm_image_types` VALUES ('6', 'Details Thumbnail', '6.000', 'member_thumb_details', '80', '80', '0', '0', '1', '1');


-- ----------------------------
-- Table structure for `cwmm_member_categories_secondary`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_member_categories_secondary`;
CREATE TABLE `cwmm_member_categories_secondary` (
  `member2secondary_id` int(11) NOT NULL AUTO_INCREMENT,
  `member2secondary_member_id` int(11) DEFAULT '0',
  `member2secondary_secondary_id` int(11) DEFAULT '0',
  PRIMARY KEY (`member2secondary_id`),
  KEY `member2secondary_member_id_idx` (`member2secondary_member_id`),
  KEY `member2secondary_secondary_id_idx` (`member2secondary_secondary_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;



-- ----------------------------
-- Table structure for `cwmm_member_images`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_member_images`;
CREATE TABLE `cwmm_member_images` (
  `member_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_image_member_id` int(11) DEFAULT '0',
  `member_image_imagetype_id` int(11) DEFAULT '0',
  `member_image_filename` varchar(255) DEFAULT NULL,
  `member_image_sortorder` float(11,3) DEFAULT '1.000',
  `member_image_caption` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_image_id`),
  KEY `member_image_member_id_idx` (`member_image_member_id`),
  KEY `member_image_imagetype_id_idx` (`member_image_imagetype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for `cwmm_members`
-- ----------------------------
DROP TABLE IF EXISTS `cwmm_members`;
CREATE TABLE `cwmm_members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_name` varchar(125) DEFAULT NULL,
  `member_address` varchar(125) DEFAULT NULL,
  `member_city` varchar(125) DEFAULT NULL,
  `member_state` varchar(25) DEFAULT NULL,
  `member_zip` varchar(12) DEFAULT NULL,
  `member_work_phone` varchar(25) DEFAULT NULL,
  `member_mobile_phone` varchar(25) DEFAULT NULL,
  `member_fax` varchar(25) DEFAULT NULL,
  `member_website` varchar(125) DEFAULT NULL,
  `member_description` text,
  `member_preview_description` text,
  `member_sort` float(11,3) DEFAULT '1.000',
  `member_on_web` smallint(6) DEFAULT '1',
  `member_archive` smallint(6) DEFAULT '0',
  `member_date_modified` datetime DEFAULT NULL,
  `member_notes` text,
  `member_keywords` text,
  `member_email1` varchar(125) DEFAULT NULL,
  `member_email2` varchar(125) DEFAULT NULL,
  `member_email3` varchar(125) DEFAULT NULL,
  `member_email4` varchar(125) DEFAULT NULL,
  `member_Primary_Contact` varchar(125) DEFAULT NULL,
  `member_Primary_Contact_Position` varchar(125) DEFAULT NULL,
  `member_other_contacts` varchar(125) DEFAULT NULL,
  `member_date_joined` varchar(255) DEFAULT NULL,
  `member_paid_years` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cwmm_members
-- ----------------------------
INSERT INTO `cwmm_members` VALUES ('1', 'Centric Web', 'Centric Web','123 Somewhere Road', 'Somewhere City', 'Illinois', '12345', '888-888-888','888-123-1234','123-456-7890', 'https://www.centricweb.com' '<p>this is a sample paragraph</p>\r\n<p>this should be a Long description</p>', '<p>This is the short description</p>', '1', '1', '0', '2016-05-16 11:26:25', '<p>this is for internal notes</p>', 'web developer, you can add more keywords for the member', 'info@centricweb.com','','','', 'Barbara ONeal', 'President/CTO', 'Melvin Renowden, someone else','January 2015', '2015,2016');


-- ----------------------------
-- END DATABASE SETUP FILE
-- ----------------------------